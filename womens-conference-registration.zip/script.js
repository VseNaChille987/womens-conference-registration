document.getElementById("registrationForm").addEventListener("submit", function (e) {
    e.preventDefault();

    const form = e.target;
    const formData = {};

    new FormData(form).forEach((value, key) => {
        formData[key] = value;
    });

    const confirmation = document.getElementById("confirmationMessage");

    fetch("https://script.google.com/macros/s/AKfycbyl4Qr4892I-DoDfmUyFMTuY1zzJ1tkqXhLXyfzTwHz9u1g1ol-pMZ5DX2eaWdiFOen/exec", {
        method: "POST",
        mode: "cors",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
    })
    .then(res => res.json())
    .then(data => {
        confirmation.textContent = data.message;
        confirmation.classList.remove("hidden");
        form.reset();
    })
    .catch(err => {
        confirmation.textContent = "Error submitting form. Please try again.";
        confirmation.classList.remove("hidden");
    });
});
