# Women's Conference Registration (GitHub Pages)

This project hosts the registration form for the 2025 Women's Conference.

After deploying to GitHub Pages, the live page will appear at:

https://VseNaChille987.github.io/womens-conference-registration/

## Files
- index.html — registration form UI
- style.css — page styling
- script.js — Google Apps Script POST logic
- README.md

## Deploy Instructions
1. Create a GitHub repo: womens-conference-registration
2. Upload all files.
3. Go to Settings → Pages.
4. Select: Branch = main → /(root).
5. Save.
6. Your website will go live in ~1 minute.
